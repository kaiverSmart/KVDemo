//
//  ViewController.swift
//  KVAttributedString
//
//  Created by 李康卫 on 16/11/8.
//  Copyright © 2016年 李康卫. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //设置UI
        setupUI()
//        testLabel.attributedText = NSMutableAttributedString.init(imageName: "compose_mentionbutton_background_highlighted", contentString: "helloEvreBodyMeimi", attributedInsertType: KVAttributedInsertType.First, label: testLabel)
//        testLabel.attributedText = NSMutableAttributedString.init(content: "还是短发hi阿萨[微笑]防守打法看见就看发的啥看法", color: UIColor.redColor(), colorString: "见就看发的")
        let nsStr =  "还是短发hi阿萨[微笑]防守打法看见就看发的啥看法还是短发hi阿萨[微笑]防守打法看见就看发的啥看法还是短发hi阿萨[微笑]防守打法看见就看发的啥看法" as NSString
        testLabel.attributedText = nsStr.emojiAttributedString()
    }
    
    private func setupUI() {
        self.view.addSubview(testLabel)
        
        testLabel.translatesAutoresizingMaskIntoConstraints = false
        
        self.view.addConstraint(NSLayoutConstraint(item: testLabel, attribute: NSLayoutAttribute.Top, relatedBy: .Equal, toItem: self.view, attribute: NSLayoutAttribute.Top, multiplier: 1, constant:50))
        self.view.addConstraint(NSLayoutConstraint(item: testLabel, attribute: NSLayoutAttribute.Leading, relatedBy: .Equal, toItem: self.view, attribute: NSLayoutAttribute.Top, multiplier: 1, constant: 50))
        self.view.addConstraint(NSLayoutConstraint(item: testLabel, attribute: NSLayoutAttribute.Trailing, relatedBy: .Equal, toItem: self.view, attribute: NSLayoutAttribute.Trailing, multiplier: 1, constant: -50))
    }

    //懒加载
    private lazy var testLabel: UILabel = {
        let label = UILabel()
        label.text = "holleWrod"
        label.textColor = UIColor.cyanColor()
        label.numberOfLines = 0
        return label;
    }()
}

