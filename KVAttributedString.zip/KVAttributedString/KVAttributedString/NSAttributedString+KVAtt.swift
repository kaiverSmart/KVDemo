
//
//  NSAttributedString+KVAtt.swift
//  KVAttributedString
//
//  Created by 李康卫 on 16/11/8.
//  Copyright © 2016年 李康卫. All rights reserved.
//

import UIKit

public enum KVAttributedInsertType : Int {
    
    case First
    case last
}

extension NSMutableAttributedString {
    ///文本前后插入图片
    convenience init(imageName: String,contentString: String ,attributedInsertType: (KVAttributedInsertType),label: UILabel){
        self.init()
        let att = NSAttributedString(string: contentString)
        self.appendAttributedString(att)
        //根据附件生成富文本
        let attachment = NSTextAttachment()
        attachment.image = UIImage(named:imageName)
//        //设置（图片）字体大小
        let attachmentH = label.font.lineHeight
        //调节图片的大小
        attachment.bounds = CGRectMake(0, -3, 25, attachmentH)
        let attString = NSAttributedString(attachment: attachment)
        if attributedInsertType == .First {
            self.insertAttributedString(attString, atIndex: 0)
        } else {
            self.insertAttributedString(attString, atIndex: (contentString as NSString).length)
        }
        
    }
    ///根据文字内容修改指定的文字的颜色
    convenience init(content: String,color: UIColor,colorString: String) {
        self.init()
        let contentAttStr = NSMutableAttributedString(string: content);
        let range: NSRange = (content as NSString).rangeOfString(colorString)
        contentAttStr.addAttribute(NSForegroundColorAttributeName, value: color, range: range)
        self.appendAttributedString(contentAttStr)
    }
    
}

extension NSString {
     func emojiAttributedString() ->NSMutableAttributedString {
        
        let plistArr = NSArray(contentsOfFile: NSBundle.mainBundle().pathForResource("emoticon.plist", ofType: nil)!)
        
        //可变的属性文本
        let attContent = NSMutableAttributedString(string: self as String)
        
        //  1.通过正则表达式取出表情图片的名称\[\w+?\]
        let pattern = "\\[\\w+?\\]"
        //        let error = NSError.init();
        print("pattern\(pattern)")
        //抛出的异常处理
        var regx = NSRegularExpression()
        do {
            regx = try NSRegularExpression(pattern: pattern, options: NSRegularExpressionOptions.init(rawValue: 0))
        } catch let error as NSError {
            print(error)
            return attContent
        }
        
        // 获的匹配结果
        //        __block NSString *emoticonName;
        let results = regx.matchesInString(self as String, options: NSMatchingOptions.init(rawValue: 0), range: NSMakeRange(0, (self as NSString).length))
        for result in results {
            let resultStr = self.substringWithRange(result.range)
            plistArr?.enumerateObjectsUsingBlock({ (obj, idx, __) in
                let desStr = obj["des"] as! String
                if desStr == resultStr {
                    let emotionName = (obj["name"])!
                    //必须要注意强拆，需要多打印调试
                    print("\(emotionName!)@2x.gif")
                    let attachment = NSTextAttachment();
                    //设置（图片）字体大小

                    attachment.bounds = CGRectMake(0, -3, 25, 25)
                    attachment.image = UIImage(named: "\(emotionName!)@2x.gif")
                
                    let emojiStr = NSAttributedString(attachment: attachment)
                    attContent .replaceCharactersInRange(result.range, withAttributedString: emojiStr)
                }
            })
        }
        return attContent
    }
}


